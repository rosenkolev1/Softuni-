/**
 * Constant used as a placeholder in firebase;
 */
export const NO_VALUE = 'empty_value_placeholder';
 